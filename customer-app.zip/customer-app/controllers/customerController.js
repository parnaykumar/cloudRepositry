var customerModel = require('../models/customerModel.js');//whenever we export module from model it will be available here
module.exports.addCustomer = function(req,res){
console.log('cc dadat',req.body);
    customerModel.create(req.body,function(err,data){
        if(err){
            return res.send({ "data": 'Somthing went wrong'});
        }else{
            return res.send({ "data": data});
        }
    });
}

module.exports.getCustomer = function(req,res){
    var customerProjection = { 
        name: true,
        _id: true
    };
    customerModel.find()
        .exec(function (err, data) {
            if (err) {
                return res.send({ "data": 'Somthing went wrong'});
            } else {
                if(data.length>0){
                    return res.send({ "data": data});
                }else{
                    return res.send({ "data": 'Record not found'});
                }
                
            }
        });
}

module.exports.getCustomerById = function(req,res){
    customerModel.findById({'_id': req.params.id})
        .exec(function (err, customer) {
        if (err) {
            return res.send({ "data": 'Somthing went wrong'});
        } else {
            return res.send({ "data": customer});
        }
    });
}