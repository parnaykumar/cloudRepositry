var express = require('express');
var router = express.Router();
//var config = require('../config/constant.js');
var demoController = require('../controllers/customerController');


// Get All Customers

router.post('/addCustomer',function(req, res, next) {
console.log('req',req.body);
        demoController.addCustomer(req,res,function(response){

console.log('res',response);
         //   res.json(response);
        });
    });
// router.get('/contact', function(req, res){

// demoController.getContactlist(req,res);
// });

router.get('/getCustomer/:id',function(req,res){
console.log('geteee',req.params.id)  //if u want to get data by id use req.params.id insde of req.body
  demoController.getCustomerById(req,res,function(response){
  console.log('getdataById',response)
  });
});

router.get('/getCustomer',function(req,res){
    // console.log('geteee',req.params.id)  //if u want to get data by id use req.params.id insde of req.body
      demoController.getCustomer(req,res,function(response){
      console.log('getdataById',response)
      });
    });


// router.post('/editContact',function(req,res){
// demoController.editContact(req,res,function(response){
//   console.log('editContact',response)
//   });
// });
// Get Single Faq
/*router.get('/:id', function(req, res){
Property.getPropertyById(req.params.id, function(err, faq){
if(err){
res.send(err);
}
res.json(faq);
});
});

// Add Faq
router.post('/', function(req, res){
var faq = req.body;
console.log("req.body",req.body);
//console.log("req.file",req.file);
Property.addproperty(faq, function(err, faq){
if(err){
res.send(err);
}
res.json(faq);
});
});

// Update Faq
router.put('/:id', function(req, res){
var id = req.params.id;
var faq = req.body;
Property.updateProperty(id, faq, {}, function(err, faq){
if(err){
res.send(err);
}
res.json(faq);
});
});


// Delete Faq
router.delete('/:id', function(req, res){
var id = req.params.id;
Property.removeProperty(id, function(err, faq){
if(err){
res.send(err);
}
res.json(faq);
});
});
*/
module.exports = router;
