var mongoose = require('mongoose');
mongoose.connect("mongodb://localhost:27017/customer1",function(){
    console.log('Mongo connection established')
})