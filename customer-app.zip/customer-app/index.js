var express = require('express');
var app = express();
require('./config/appConfig');
console.log('start on port 3000....');
var bodyParser = require('body-parser');
var customerRoutes = require('./routes/appRoutes');
// app.use(express.static(__dirname+'/frontend')); ///to load index.html by default
app.use(bodyParser.json({limit:'50mb'}));
app.use('/api', customerRoutes);
app.listen(3000);

